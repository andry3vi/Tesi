rm -drf Fit_inspect_tmp
mkdir Fit_inspect_tmp
root -q ADSorter.C
