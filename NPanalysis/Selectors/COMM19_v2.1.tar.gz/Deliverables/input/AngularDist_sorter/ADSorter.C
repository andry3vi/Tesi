/*ROOT MACRO to plot the required figures for MUGAST paper*/

//INCLUDE//
#include <iostream>
#include <fstream>
#include <TPaveStats.h>
#include <cstdlib>
#include "RooRealVar.h"
#include "RooDataSet.h"
#include "RooDataHist.h"
#include "RooGaussian.h"
#include "RooAddPdf.h"
#include "RooPlot.h"
//INCLUDE//
using namespace RooFit;


//Output_NTuple = new TNtuple("COMM19", "COMM19", "Ex:Elab:ThLAB:ThCM:ETrack:EAdd:DoppETrack:DoppEAdd:IC1:IC2:MW_Nr");

//INPUT FILES//
string data_Filename 							= "../data/COMM19.root";   // TNtuple containing the sorted data from the Commissioning
string EfficiencyAD_Filename 			= "../data/EfficiencyAD.root";    //Simulated angular distribution

string O17_12p_xsec_Filename 			= "../xsec/16Odp17O_12p.dat";   // 1st excited state transfer cross section
string O17_52p_xsec_Filename 			= "../xsec/16Odp17O_52p.dat";   //	g.s. cross transfer section

string O17_12p_xsec_Tarek_Filename 			= "../xsec/12_p_Tarek.txt";   // 1st excited state transfer cross section
string O17_52p_xsec_Tarek_Filename 			= "../xsec/52_p_Tarek.txt";   //	g.s. cross transfer section
//INPUT FILES//

TGraph * O17_12p_xsec = new TGraph(O17_12p_xsec_Filename.c_str());
TGraph * O17_52p_xsec = new TGraph(O17_52p_xsec_Filename.c_str());
TGraph * O17_12p_xsec_Tarek = new TGraph(O17_12p_xsec_Tarek_Filename.c_str());
TGraph * O17_52p_xsec_Taraek = new TGraph(O17_52p_xsec_Tarek_Filename.c_str());

Double_t FitFunction52p(Double_t *v,Double_t *par) {

	Double_t cross = O17_52p_xsec->Eval(v[0]);
	Double_t value = par[0]*cross;

	return value;
}

Double_t FitFunction12p(Double_t *v,Double_t *par) {

	Double_t cross = O17_12p_xsec->Eval(v[0]);
	Double_t value = par[0]*cross;

	return value;
}

std::vector<float> PeakCounter(TH1F * Ex, string name){

	// Declare observable x
	RooRealVar x("x", "x", -2, 2);

	// Create two Gaussian PDFs g1(x,mean1,sigma) anf g2(x,mean2,sigma) and their parameters
	RooRealVar mean_GS("mean_GS", "mean of gaussians", 0,-0.5,0.5);
	RooRealVar mean_FS("mean_FS", "mean of gaussians", 0.870,0.5,1);
	RooRealVar sigma_GS("sigma_GS", "width of gaussians", 0.2,0.1,0.3);
	RooRealVar sigma_FS("sigma_FS", "width of gaussians", 0.2,0.1,0.3);

	RooGaussian gaus_GS("gaus_GS", "Signal component 1", x, mean_GS, sigma_GS);
	RooGaussian gaus_FS("gaus_FS", "Signal component 2", x, mean_FS, sigma_FS);

	// Sum the signal components into a composite signal p.d.f.
	RooRealVar sig_GS_frac("sig_GS_frac","fraction of component 1 in signal",0.5,0.,1.) ;
	RooAddPdf sig("sig","Signal",RooArgList(gaus_GS,gaus_FS),sig_GS_frac) ;


	// Build Chebychev polynomial p.d.f.
	RooRealVar a0("a0", "a0", 0.5, 0., 1.);
	RooRealVar a1("a1", "a1", 0.2, 0., 1.);
	RooRealVar a2("a2", "a2", 0.2, 0., 1.);
	RooRealVar a3("a3", "a3", 0.2, 0., 1.);
	RooRealVar a4("a4", "a4", 0.2, 0., 1.);
	RooChebychev bkg("bkg", "Background", x, RooArgSet(a0, a1, a2, a3, a4));

	// Associated nsig/nbkg as expected number of events with sig/bkg _in_the_range_ "signalRange"
	RooRealVar nsig("nsig","number of signal events in signalRange",500,0.,50000) ;
	RooRealVar nbkg("nbkg","number of background events in signalRange",500,0.,50000) ;

	// Use AddPdf to extend the model. Giving as many coefficients as pdfs switches
	// on extension.
	RooAddPdf  model("model","(g1+g2)+a", RooArgList(bkg,sig), RooArgList(nbkg,nsig)) ;


	RooDataHist *data = new RooDataHist("dh", "dh", x, Import(*Ex));

	// Fit model to data
	model.fitTo(*data,PrintLevel(-1));

	cout<<endl<<"###########"<<name<<"###########"<<endl;
	cout<<"GS mean and sigma -> "<<mean_GS.getVal()<<" - "<<sigma_GS.getVal()<<endl;
	cout<<"FS mean and sigma -> "<<mean_FS.getVal()<<" - "<<sigma_FS.getVal()<<endl;

	TCanvas *C = new  TCanvas(name.c_str(),name.c_str());
	C->Divide(2,2);

	// Plot data and PDF overlaid
	RooPlot *xframe = x.frame(Title(name.c_str()));
	data->plotOn(xframe, XErrorSize(0));

	//model.plotOn(xframe);


	// Overlay the background+sig2 components of model with a dotted line
	model.plotOn(xframe, Components(bkg));
	//model.plotOn(xframe, Components(RooArgSet(gaus_GS, gaus_FS)),  LineStyle(kDashed));
	C->cd(1);
	xframe->Draw();

	// Plot data and PDF overlaid
	RooPlot *xframe2 = x.frame(Title(name.c_str()));
	data->plotOn(xframe2, XErrorSize(0));
	model.plotOn(xframe2);
	// Overlay the background component of model with a dashed line


	C->cd(2);
	xframe2->Draw();
	// Print structure of composite p.d.f.
	//model.Print("t");

	//bkg subtraction
	TH1F *subbkg = (TH1F*) bkg.createHistogram("subbkg",x,Binning(100,-4,4));
	TH1F *subGS = (TH1F*) gaus_GS.createHistogram("subGS",x,Binning(100,-4,4));
	TH1F *subFS = (TH1F*) gaus_FS.createHistogram("subFS",x,Binning(100,-4,4));

	TH1F * Ex_FS = (TH1F*)Ex->Clone();
	TH1F * Ex_GS = (TH1F*)Ex->Clone();

	Ex_FS->Add(subbkg,-double(nbkg.getVal()));
	Ex_GS->Add(subbkg,-double(nbkg.getVal()));
	Ex_FS->Add(subGS,-double(sig_GS_frac.getVal()*nsig.getVal()));
	Ex_GS->Add(subFS,-double((1.-sig_GS_frac.getVal())*nsig.getVal()));


	TH1F * Ex_FS_peak = (TH1F*)Ex_FS->Clone();
	TH1F * Ex_GS_peak = (TH1F*)Ex_GS->Clone();

	std::vector<double> GS_range;
	std::vector<double> FS_range;

	GS_range.push_back(mean_GS.getVal()-2.355*sigma_GS.getVal());
	GS_range.push_back(mean_GS.getVal()+2.355*sigma_GS.getVal());

	FS_range.push_back(mean_FS.getVal()-2.355*sigma_FS.getVal());
	FS_range.push_back(mean_FS.getVal()+2.355*sigma_FS.getVal());

	cout<<"---Integration ranges---"<<endl;
	cout<<"Ground State -> "<<GS_range[0]<<" <-> "<<GS_range[1]<<endl;
	cout<<"First State  -> "<<FS_range[0]<<" <-> "<<FS_range[1]<<endl;


	C->cd(3);
	Ex_GS->GetYaxis()->SetRangeUser(0,250);
	Ex_GS->GetXaxis()->SetRangeUser(-4,4);
	Ex_GS->Draw("E1");


	Ex_GS_peak->GetXaxis()->SetRangeUser(GS_range[0],GS_range[1]);
	Ex_GS_peak->SetFillColor(kRed);
	Ex_GS_peak->SetFillStyle(3003);
	Ex_GS_peak->Draw("SAME");

	int bmin_GS = Ex_GS->GetXaxis()->FindBin(GS_range[0]);
  int bmax_GS = Ex_GS->GetXaxis()->FindBin(GS_range[1]);

  double integral_GS = Ex_GS->Integral(bmin_GS,bmax_GS);

  integral_GS -= Ex_GS->GetBinContent(bmin_GS)*(GS_range[0]-Ex_GS->GetXaxis()->GetBinLowEdge(bmin_GS))/Ex_GS->GetXaxis()->GetBinWidth(bmin_GS);
  integral_GS -= Ex_GS->GetBinContent(bmax_GS)*(Ex_GS->GetXaxis()->GetBinUpEdge(bmax_GS)-GS_range[1])/Ex_GS->GetXaxis()->GetBinWidth(bmax_GS);

	C->cd(4);
	Ex_FS->GetYaxis()->SetRangeUser(0,250);
	Ex_FS->GetXaxis()->SetRangeUser(-4,4);
	Ex_FS->Draw("E1");
	Ex_FS_peak->GetXaxis()->SetRangeUser(FS_range[0],FS_range[1]);

	Ex_FS_peak->SetFillColor(kRed);
	Ex_FS_peak->SetFillStyle(3003);
	Ex_FS_peak->Draw("SAME");

  int bmin_FS = Ex_FS->GetXaxis()->FindBin(FS_range[0]);
  int bmax_FS = Ex_FS->GetXaxis()->FindBin(FS_range[1]);

  double integral_FS = Ex_FS->Integral(bmin_FS,bmax_FS);

  integral_FS -= Ex_FS->GetBinContent(bmin_FS)*(FS_range[0]-Ex_FS->GetXaxis()->GetBinLowEdge(bmin_FS))/Ex_FS->GetXaxis()->GetBinWidth(bmin_FS);
  integral_FS -= Ex_FS->GetBinContent(bmax_FS)*(Ex_FS->GetXaxis()->GetBinUpEdge(bmax_FS)-FS_range[1])/Ex_FS->GetXaxis()->GetBinWidth(bmax_FS);

	cout<<"---Integration results---"<<endl;
	cout<<"Ground State -> "<<integral_GS<<endl;
	cout<<"First State  -> "<<integral_FS<<endl;
	C->SaveAs(("Fit_inspect_tmp/"+name+".png").c_str());
	C->SaveAs(("Fit_inspect_tmp/"+name+".root").c_str());


	cout<<"#############################"<<endl;

	delete data;
	delete xframe;
	delete C;
	//bkg subtraction
	delete subbkg;
	delete subGS ;
	delete subFS ;
	delete Ex_FS ;
	delete Ex_GS ;
	std::vector<float> integrals;
	integrals.push_back(integral_GS);
	integrals.push_back(integral_FS);
	return integrals;

}

void ADSorter()
{
	TFile * EfficiencyAD_File = new TFile( EfficiencyAD_Filename.c_str());
	TFile *data_File = new TFile(data_Filename.c_str());

	TH1F * EfficiencyAD = (TH1F*) EfficiencyAD_File->Get("ThCMEff");
	TTree *data_Tree = (TTree*)data_File->Get("COMM19");

	float Ex, Elab, ThLAB, ThCM;

	data_Tree->SetBranchAddress("Ex",&Ex);
	data_Tree->SetBranchAddress("Elab",&Elab);
	data_Tree->SetBranchAddress("ThLAB",&ThLAB);
	data_Tree->SetBranchAddress("ThCM",&ThCM);

	// number of entries
	Int_t nentries = (Int_t)data_Tree->GetEntries();

	std::vector<float> Ex_vector;
	std::vector<float> Elab_vector;
	std::vector<float> ThLAB_vector;
	std::vector<float> ThCM_vector;

	Ex_vector.reserve(nentries);
	Elab_vector.reserve(nentries);
	ThLAB_vector.reserve(nentries);
	ThCM_vector.reserve(nentries);

	TH1F * Ex_histo = new TH1F("Ex","Ex",100,-4,4);

	TH1F * THCM_GS = new TH1F("THCM_GS","THCM_GS",90,0,90);
	TH1F * THCM_FS = new TH1F("THCM_FS","THCM_FS",90,0,90);


	for (Int_t i=0;i<nentries;i++) {

		data_Tree->GetEntry(i);
		if(Ex != -1000){
			Ex_histo->Fill(Ex);
			if(Ex>-0.465384 && Ex<=0.370211) THCM_GS->Fill(ThCM);
			if(Ex>0.191296 && Ex<=1.45479) THCM_FS->Fill(ThCM);
			Ex_vector.push_back(Ex);
		  Elab_vector.push_back(Elab);
		  ThLAB_vector.push_back(ThLAB);
		  ThCM_vector.push_back(ThCM);
		}
	}

	int points = 7;
	std::vector<int> range;
	range.push_back(4);
	range.push_back(36);

	//Ground state discretization
	int bmin_GS = THCM_GS->GetXaxis()->FindBin(range[0]);
	int bmax_GS = THCM_GS->GetXaxis()->FindBin(range[1]);

	double integral_GS = THCM_GS->Integral(bmin_GS,bmax_GS);
	double integral_step_GS = integral_GS/double(points);

	std::vector<int> ranges_GS;
	ranges_GS.push_back(range[0]);
	for(int i=range[0]; i<range[1]; i++){
		int bmin = THCM_GS->GetXaxis()->FindBin(ranges_GS.back());
		int bmax = THCM_GS->GetXaxis()->FindBin(i);

		double integral = THCM_GS->Integral(bmin,bmax);

		if(integral >= integral_step_GS) ranges_GS.push_back(i);

	}
	//ranges_GS.push_back(range[1]);

	//First excited state discretization
	int bmin_FS = THCM_FS->GetXaxis()->FindBin(range[0]);
	int bmax_FS = THCM_FS->GetXaxis()->FindBin(range[1]);

	double integral_FS = THCM_FS->Integral(bmin_FS,bmax_FS);
	double integral_step_FS = integral_FS/double(points);

	std::vector<int> ranges_FS;
	ranges_FS.push_back(range[0]);
	for(int i=range[0]; i<range[1]; i++){
		int bmin = THCM_FS->GetXaxis()->FindBin(ranges_FS.back());
		int bmax = THCM_FS->GetXaxis()->FindBin(i);

		double integral = THCM_FS->Integral(bmin,bmax);

		if(integral > integral_step_FS) ranges_FS.push_back(i);

	}
	ranges_FS.push_back(range[1]);


	cout<<endl<<endl;
	//MANUAL definition of ranges
	// //4 7 9 13 16 21 25 29 32 35 39
	// ranges_GS.clear();
	// ranges_GS.push_back(4);
	// ranges_GS.push_back(7);
	// ranges_GS.push_back(9);
	// ranges_GS.push_back(13);
	// ranges_GS.push_back(16);
	// ranges_GS.push_back(21);
	// ranges_GS.push_back(25);
	// ranges_GS.push_back(29);
	// ranges_GS.push_back(32);
	// ranges_GS.push_back(35);
	// ranges_GS.push_back(39);
	// //4 7 9 11 15 17 20 23 28 31 34 39
	// ranges_FS.clear();
	// ranges_FS.push_back(4);
	// ranges_FS.push_back(7);
	// ranges_FS.push_back(9);
	// ranges_FS.push_back(11);
	// ranges_FS.push_back(15);
	// ranges_FS.push_back(17);
	// ranges_FS.push_back(20);
	// ranges_FS.push_back(23);
	// ranges_FS.push_back(28);
	// ranges_FS.push_back(31);
	// ranges_FS.push_back(34);
	// ranges_FS.push_back(39);


	std::vector<float> AD_GS;
	//gROOT->SetBatch(kTRUE);
	std::vector<TH1F*> Ex_ranges_GS;
	for (size_t i = 0; i < ranges_GS.size()-1; i++) {
		string name = "GSintegration_"+to_string(ranges_GS[i])+"_"+to_string(ranges_GS[i+1]);
		Ex_ranges_GS.push_back(new TH1F(name.c_str(),name.c_str(),100,-4,4));
		for (size_t j = 0; j < Ex_vector.size(); j++) {
			if(ThCM_vector[j]>ranges_GS[i] && ThCM_vector[j]<=ranges_GS[i+1]) Ex_ranges_GS.back()->Fill(Ex_vector[j]);
		}
		AD_GS.push_back(PeakCounter(Ex_ranges_GS.back(), name.c_str())[0]);
	}

	std::vector<float> AD_FS;
	gROOT->SetBatch(kTRUE);
	std::vector<TH1F*> Ex_ranges_FS;
	for (size_t i = 0; i < ranges_FS.size()-1; i++) {
		string name = "FSintegration_"+to_string(ranges_FS[i])+"_"+to_string(ranges_FS[i+1]);
		Ex_ranges_FS.push_back(new TH1F(name.c_str(),name.c_str(),100,-4,4));
		for (size_t j = 0; j < Ex_vector.size(); j++) {
			if(ThCM_vector[j]>ranges_FS[i] && ThCM_vector[j]<=ranges_FS[i+1]) Ex_ranges_FS.back()->Fill(Ex_vector[j]);
		}
		AD_FS.push_back(PeakCounter(Ex_ranges_FS.back(), name.c_str())[1]);
	}

	cout<<endl<<"Ground state limits with step->"<<integral_step_GS<<" and total events->"<<integral_GS<<endl;
	for (auto & border : ranges_GS) {
				cout<<border<<" ";
	}

	cout<<endl<<"First excited state limits with step->"<<integral_step_FS<<" and total events->"<<integral_FS<<endl;
	for (auto & border : ranges_FS) {
				cout<<border<<" ";
	}
	cout<<endl;
	gROOT->SetBatch(kTRUE);
	TGraphErrors * Angular_dist_GS = new TGraphErrors(AD_GS.size());
	for (size_t i = 0; i < AD_GS.size(); i++) {
		double x 			= (ranges_GS[i+1]+ranges_GS[i])*0.5;
		double y 			= AD_GS[i];
		double x_err	= (ranges_GS[i+1]-ranges_GS[i])*0.5;
		double y_err  = sqrt(AD_GS[i]);

		//
		int bmin = EfficiencyAD->GetXaxis()->FindBin(ranges_GS[i]);
		int bmax = EfficiencyAD->GetXaxis()->FindBin(ranges_GS[i+1]);
		//

		double Eff = EfficiencyAD->Integral(bmin,bmax);


		Angular_dist_GS->SetPoint(i,x,y/Eff);
		Angular_dist_GS->SetPointError(i,x_err,sqrt(pow(y_err/(Eff),2)+pow(y*sqrt(Eff)/(Eff*Eff),2)));

	}

	TGraphErrors * Angular_dist_FS = new TGraphErrors(AD_FS.size());
	for (size_t i = 0; i < AD_FS.size(); i++) {
		double x 			= (ranges_FS[i+1]+ranges_FS[i])*0.5;
		double y 			= AD_FS[i];
		double x_err	= (ranges_FS[i+1]-ranges_FS[i])*0.5;
		double y_err  = sqrt(AD_FS[i]);

		//
		int bmin = EfficiencyAD->GetXaxis()->FindBin(ranges_FS[i]);
		int bmax = EfficiencyAD->GetXaxis()->FindBin(ranges_FS[i+1]);
		//

		double Eff = EfficiencyAD->Integral(bmin,bmax);


		Angular_dist_FS->SetPoint(i,x,y/Eff);
		Angular_dist_FS->SetPointError(i,x_err,sqrt(pow(y_err/(Eff),2)+pow(y*sqrt(Eff)/(Eff*Eff),2)));

	}

	TF1 * fit52p = new TF1("fit52p",FitFunction52p,15,35,1);

	fit52p->SetParameter(0,1E3);

	Angular_dist_GS->Fit("fit52p","RWN");
	double rescaling52p = fit52p->GetParameter(0);

	TF1 * fit12p = new TF1("fit12p",FitFunction12p,15,35,1);

	fit12p->SetParameter(0,400);

	Angular_dist_FS->Fit("fit12p","RWN");
	double rescaling12p = fit12p->GetParameter(0);

	for (size_t i = 0; i < AD_FS.size(); i++) {

		Angular_dist_FS->SetPointY(i,Angular_dist_FS->GetPointY(i)/rescaling52p); //12p for different rescasling
		Angular_dist_FS->SetPointError(i,Angular_dist_FS->GetErrorX(i),Angular_dist_FS->GetErrorY(i)/rescaling12p);

	}

	for (size_t i = 0; i < AD_GS.size(); i++) {

		Angular_dist_GS->SetPointY(i,Angular_dist_GS->GetPointY(i)/rescaling52p);
		Angular_dist_GS->SetPointError(i,Angular_dist_GS->GetErrorX(i),Angular_dist_GS->GetErrorY(i)/rescaling12p);


	}


	gROOT->SetBatch(kFALSE);
	TCanvas *C = new TCanvas("ADist_canvas","C");


	C->SetLogy();

	Angular_dist_FS->SetLineColor(kBlue);
	Angular_dist_FS->SetLineWidth(2);
	Angular_dist_FS->GetYaxis()->SetRangeUser(5,4E2);
	Angular_dist_FS->GetXaxis()->SetRangeUser(0,45);
	Angular_dist_FS->GetXaxis()->SetTitle("#theta_{CM} [deg.]");
	Angular_dist_FS->GetYaxis()->SetTitle("d#sigma/d#Omega [a.u.]");
	Angular_dist_FS->SetTitle("");
	Angular_dist_FS->Draw("AP");

	O17_12p_xsec->Draw("SAME");
	O17_52p_xsec->Draw("SAME");


	O17_12p_xsec_Tarek->Draw("SAME");
	O17_52p_xsec_Taraek->Draw("SAME");



	Angular_dist_GS->SetLineColor(kRed);
	Angular_dist_GS->SetLineWidth(2);
	Angular_dist_GS->Draw("SAMEP");

	C->Update();
	C->SaveAs("../data/ADist_tmp.root");


	return ;
}
