# *Plot.C*
## Root macro to plot:
- Angular Dist.
- Kinematic plot
- Excitation energy plot of Commissioning experiment
- Gamma spectrum

## How to use
*root Plot.C*

### Angular distribution
The two distributions are automatically computed by ADSorter in input/AngularDist_sorter. If needed they can be recomputed by calling *./execute.sh* . (The code is a nightmare, sorry :D)
The macro automatically evaluate the best CM angular slicing and fit with RooFit the corresponding excitation spectra. The integral of the peaks after background removal is accounted and plotted after efficiency renormalization. The sorter save the canvas in input/data/ADist_tmp.root which can be renamed in ADist.root (Safe save in order to avoid unwanted replacement). Plot.C will automatically import the generated Canvas.

### Kinematic plot
Energy of the proton in Laboratory frame vs ThetaLab plot. The plot is focused in the MUGAST angular region. Energy of the proton reconstructed computing energy loss at mid target reaction and dead silicon layer. On the annular a randomization of theta is applied to account for spatial resolution.

### Excitation Energy Plot
Plot obtained computing the excitation energy of 17O produced by the reaction starting from the proton energy measured by the detectors. Only the particles on MUGAST are used for this plot(assumed to be protons).
In Red are represented the event selected with Vamos IC condition.

### Gamma spectra
Canvas containing the gamma spectra from the Commissioning with different condition.(can be 'easily' modified in the code).
First spectrum is obtained without any condition.
Second spectrum is obtained with Mugast Ex gate on 1/2 peak and applying doppler correction.
Third spectrum is obtained with Vamos IC condition + Mugast Ex gate on 1/2 peak and applying doppler correction.
