/*ROOT MACRO to plot the required figures for MUGAST paper*/

//INCLUDE//
#include <iostream>
#include <fstream>
#include <TPaveStats.h>
#include "include/colormod.h"
//INCLUDE//

//INPUT FILES//


string O17_12p_KineLine_Filename  = "input/xsec/KinematicLineFS.dat";   // 1st excited state kinematic line
string O17_52p_KineLine_Filename  = "input/xsec/KinematicLineGS.dat";   //g.s. kinematic line
string ADist_Filename 						= "input/data/ADist.root";   // ADistribution canvas
string data_Filename 							= "input/data/COMM19.root";   // TNtuple containing the sorted data from the Commissioning
string Gamma_Filename 						= "input/data/AddE_spectrum.root";   // TNtuple containing the sorted data from the Commissioning

string O17_12p_alty_Filename  = "input/xsec/alty12.dat";   // 1st excited state kinematic line
string O17_52p_alty_Filename  = "input/xsec/alty52.dat";   // 1st excited state kinematic line

//INPUT FILES//
//Output_NTuple = new TNtuple("COMM19", "COMM19", "Ex:Elab:ThLAB:ThCM:ETrack:EAdd:DoppETrack:DoppEAdd:IC1:IC2:MW_Nr");

void printProgBar( float percent){
	std::string bar;

	for(int i = 0; i < 50; i++){
		if( i < (int(percent)/2)){
			bar.replace(i,1,"=");
		}else if( i == int(percent/2)){
			bar.replace(i,1,">");
		}else{
			bar.replace(i,1," ");
		}
	}

	Color::Modifier red(Color::FG_RED);
	Color::Modifier def(Color::FG_DEFAULT);
	Color::Modifier green(Color::FG_GREEN);

	std::cout<<"\r [" << red << bar << def <<"]";
	std::cout.width( 3 );
	std::cout<< std::fixed;
	std::cout<< std::setprecision(2);

	std::cout<< green << percent << def << "%"<< std::flush;

}

void Plot()
{

	gStyle->SetOptStat(0);

	TFile *data_File = new TFile(data_Filename.c_str());
	TFile *ADist_File = new TFile(ADist_Filename.c_str());
	TFile *Gamma_File = new TFile(Gamma_Filename.c_str());


	TTree *data_Tree = (TTree*)data_File->Get("COMM19");
	TCanvas *ADist_canvas = (TCanvas*)ADist_File->Get("ADist_canvas");
	TH1F * hGamma = (TH1F*)Gamma_File->Get("AddE");

	float Ex, Elab, ThLAB, ThCM, ETrack, EAdd, DoppETrack, DoppEAdd, IC1, IC2, MW_Nr;

	data_Tree->SetBranchAddress("Ex",&Ex);
	data_Tree->SetBranchAddress("Elab",&Elab);
	data_Tree->SetBranchAddress("ThLAB",&ThLAB);
	data_Tree->SetBranchAddress("ThCM",&ThCM);
	data_Tree->SetBranchAddress("ETrack",&ETrack);
	data_Tree->SetBranchAddress("EAdd",&EAdd);
	data_Tree->SetBranchAddress("DoppETrack",&DoppETrack);
	data_Tree->SetBranchAddress("DoppEAdd",&DoppEAdd);
	data_Tree->SetBranchAddress("IC1",&IC1);
	data_Tree->SetBranchAddress("IC2",&IC2);
	data_Tree->SetBranchAddress("MW_Nr",&MW_Nr);

	// number of entries
	Int_t nentries = (Int_t)data_Tree->GetEntries();

	//plot list
	TH2F * hELabThLab = new TH2F("hELabThLab","hELabThLab",80,100,180,1000,0,10);
	TH1F * hEx = new TH1F("hEx","hEx",500,-10,10);
	TH1F * hEx_VamosGated = new TH1F("hEx_VamosGated","hEx_VamosGated",500,-10,10);

	TH1F * hGamma_VamosGated = new TH1F("hGamma_VamosGated","hGamma_VamosGated",2000,0,2000);
	TH1F * hGamma_VamosMugastGated_DoppCorr= new TH1F("hGamma_VamosMugastGated","hGamma_VamosMugastGated",2000,0,2000);
	TH1F * hGamma_MugastGated= new TH1F("hGamma_MugastGated","hGamma_MugastGated",2000,0,2000);
	TH1F * hGamma_MugastGated_DoppCorr= new TH1F("hGamma_MugastGated_DoppCorr","hGamma_MugastGated_DoppCorr",2000,0,2000);

	for (Int_t i=0;i<nentries;i++) {
		/*EX peaks
		Ground state 5/2
		1  p0           2.57846e+02   6.50148e+00   3.75569e-02  -6.30018e-06
		2  p1          -4.83882e-02   4.98889e-03   3.08137e-05   7.51990e-03
		3  p2           1.78037e-01   3.83195e-03   1.97505e-05   3.15032e-03
		Excited state 1/2
		4  p3           1.80820e+02   4.97440e+00   2.58436e-02   1.59008e-05
   	5  p4           8.24638e-01   7.17078e-03   4.64632e-05  -1.31154e-02
   	6  p5           2.75050e-01   7.62552e-03   3.52672e-05   1.58482e-02
		*/
		if(i%1000 == 0) printProgBar(i*100.0/nentries);
		data_Tree->GetEntry(i);
		if(Elab != -1000)																								hELabThLab->Fill(ThLAB,Elab);
		if(Ex 	!= -1000)																								hEx->Fill(Ex);
		if(Ex		!= -1000 && IC2>1) 																			hEx_VamosGated->Fill(Ex);
		if(IC2>1 && Ex>(0.87-0.27) && Ex<=(0.87+0.27) && DoppEAdd != -1000) hGamma_VamosMugastGated_DoppCorr->Fill(DoppEAdd);
		if(Ex>(0.87-0.27) && Ex<=(0.87+0.27) && EAdd != -1000)          hGamma_MugastGated->Fill(EAdd);
		if(Ex>(0.87-0.27) && Ex<=(0.87+0.27) && DoppEAdd != -1000)      hGamma_MugastGated_DoppCorr->Fill(DoppEAdd);


	}

	//-----------------------------------------------------------//
	//------------EXCITATION ENERGY AND KINEMATIC PLOT-----------//
	//-----------------------------------------------------------//
	TGraph * O17_12p_KineLine = new TGraph(O17_12p_KineLine_Filename.c_str());
	TGraph * O17_52p_KineLine = new TGraph(O17_52p_KineLine_Filename.c_str());

	TGraph * O17_12p_alty = new TGraph(O17_12p_alty_Filename.c_str());
	TGraph * O17_52p_alty = new TGraph(O17_52p_alty_Filename.c_str());
	for (int i=0;i<O17_12p_alty->GetN();i++) O17_12p_alty->GetY()[i] *= 1000;
	for (int i=0;i<O17_52p_alty->GetN();i++) O17_52p_alty->GetY()[i] *= 1000;

	TCanvas * C1 = new TCanvas("C1","C1");
	C1->cd();

	hELabThLab->GetYaxis()->SetRangeUser(1,5);
	hELabThLab->GetXaxis()->SetRangeUser(100,170);
	hELabThLab->GetXaxis()->SetTitle("#theta_{LAB} [deg.]");
	hELabThLab->GetYaxis()->SetTitle("p Energy [MeV]");
	hELabThLab->SetTitle("");
	hELabThLab->Draw("col");

	O17_12p_KineLine->SetLineColor(kBlue);
	O17_12p_KineLine->SetLineWidth(2);
	O17_12p_KineLine->Draw("SAME");

	O17_52p_KineLine->SetLineColor(kRed);
	O17_52p_KineLine->SetLineWidth(2);
	O17_52p_KineLine->Draw("SAME");

	TCanvas * C2 = new TCanvas("C2","C2");
	C2->cd();

	hEx->GetXaxis()->SetTitle("^{17}O Excitation Energy [MeV]");
	hEx->GetYaxis()->SetTitle("counts/40 keV");

	hEx->SetTitle("");
	hEx->Draw();

	hEx_VamosGated->GetXaxis()->SetTitle("^{17}O Excitation Energy [MeV]");
	hEx_VamosGated->GetYaxis()->SetTitle("counts/40 keV");

	hEx_VamosGated->SetTitle("");
	hEx_VamosGated->SetLineColor(kRed);
	hEx_VamosGated->Draw("SAME");
	//-----------------------------------------------------------//
	//------------EXCITATION ENERGY AND KINEMATIC PLOT-----------//
	//-----------------------------------------------------------//

	//-----------------------------------------------------------//
	//-------------------------GAMMA PLOT------------------------//
	//-----------------------------------------------------------//
	TCanvas * C3 = new TCanvas("C3","C3");
	C3->Divide(1,3);
	C3->cd(1);
	hGamma->GetXaxis()->SetTitle("Energy [MeV]");
	hGamma->GetYaxis()->SetTitle("counts/1 keV");
	hGamma->SetTitle("No conditions");
	hGamma->Draw();

	C3->cd(2);
	hGamma_MugastGated_DoppCorr->GetXaxis()->SetTitle("Energy [MeV]");
	hGamma_MugastGated_DoppCorr->Rebin(4);
	hGamma_MugastGated_DoppCorr->GetYaxis()->SetTitle("counts/4 keV");
	hGamma_MugastGated_DoppCorr->SetTitle("Mugast gate Doppler corrected");
	hGamma_MugastGated_DoppCorr->Draw();

	C3->cd(3);
	hGamma_VamosMugastGated_DoppCorr->GetXaxis()->SetTitle("Energy [MeV]");
	hGamma_VamosMugastGated_DoppCorr->GetYaxis()->SetTitle("counts/4 keV");
	hGamma_VamosMugastGated_DoppCorr->Rebin(4);
	hGamma_VamosMugastGated_DoppCorr->SetTitle("Vamos+Mugast gate Doppler corrected");
	hGamma_VamosMugastGated_DoppCorr->Draw();
	//-----------------------------------------------------------//
	//-------------------------GAMMA PLOT------------------------//
	//-----------------------------------------------------------//

	ADist_canvas->Draw();
	ADist_canvas->cd();
	//O17_12p_alty->Draw("SAME");
	//O17_52p_alty->Draw("SAME");

	return ;
}
